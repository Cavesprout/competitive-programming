"""
Tavi Logan
Spring 2023 Contest Analysis & Improvement Plan
April 17 2023

In all 3 contests taken, a significant portion of the time I'd allotted myself was
wasted on a single problem - I approached these contests attempting to challenge myself
as much as possible attempting problem types I was unfamiliar with, rather than complete 
as many questions as possible in the time available.
As such, a lot of the easy points were left to waste so I could focus my little time on 
problems I found interesting. If I were to participate in an actual programming competition
I would likely take a different approach, but I'm here for practice, not points, so whatever.


Weaknesses
    The most popular lecture problem type this semester seemed to be graph traversal, 
    so I attempted a problem or two with a graph traversal solution, and found it to
    be much harder than anticipated simply due to being unfamiliar with implementing them.
    Although I was able to theorize solutions for these problems, I wasn't able to successfully
    put my solution into code.
"""


